//
// Copyright (c) Microsoft. All rights reserved.
// See https://aka.ms/azai/vision/license202012 for the full license information.
//

#pragma once
#include <azac_api_c_common.h>

// TODO: TFS#3671215 - Vision: C/C++ azac_api* files are in shared include directory, speech and vision share

AZAC_API__(const char*) ai_core_string_create(const char* str, size_t size);
AZAC_API_(void) ai_core_string_free(const char* str);

AZAC_API_(int) ai_core_json_parser_create(AZAC_HANDLE* parser, const char* json, size_t jsize); // returns item for root
AZAC_API_(bool) ai_core_json_parser_handle_is_valid(AZAC_HANDLE parser);
AZAC_API ai_core_json_parser_handle_release(AZAC_HANDLE parser);

AZAC_API_(int) ai_core_json_builder_create(AZAC_HANDLE* builder, const char* json, size_t jsize); // returns item for root
AZAC_API_(bool) ai_core_json_builder_handle_is_valid(AZAC_HANDLE builder);
AZAC_API ai_core_json_builder_handle_release(AZAC_HANDLE builder);

AZAC_API_(int) ai_core_json_item_count(AZAC_HANDLE parserOrBuilder, int item);
AZAC_API_(int) ai_core_json_item_at(AZAC_HANDLE parserOrBuilder, int item, int index, const char* find); // returns item found
AZAC_API_(int) ai_core_json_item_next(AZAC_HANDLE parserOrBuilder, int item); // returns next item
AZAC_API_(int) ai_core_json_item_name(AZAC_HANDLE parserOrBuilder, int item); // returns item representing name of item specified

AZAC_API_(int) ai_core_json_value_kind(AZAC_HANDLE parserOrBuilder, int item);
AZAC_API_(bool) ai_core_json_value_as_bool(AZAC_HANDLE parserOrBuilder, int item, bool defaultValue);
AZAC_API_(double) ai_core_json_value_as_double(AZAC_HANDLE parserOrBuilder, int item, double defaultValue);
AZAC_API_(int64_t) ai_core_json_value_as_int(AZAC_HANDLE parserOrBuilder, int item, int64_t defaultValue);
AZAC_API_(uint64_t) ai_core_json_value_as_uint(AZAC_HANDLE parserOrBuilder, int item, uint64_t defaultValue);

AZAC_API__(const char*) ai_core_json_value_as_string_ptr(AZAC_HANDLE parserOrBuilder, int item, size_t* size);

AZAC_API__(const char*) ai_core_json_value_as_string_copy(AZAC_HANDLE parserOrBuilder, int item, const char* defaultValue);
AZAC_API__(const char*) ai_core_json_value_as_json_copy(AZAC_HANDLE parserOrBuilder, int item);

AZAC_API_(int) ai_core_json_builder_item_add(AZAC_HANDLE builder, int item, int index, const char* find);
AZAC_API ai_core_json_builder_item_set(AZAC_HANDLE builder, int item, const char* json, size_t jsize, int kind, const char* str, size_t ssize, bool boolean, int integer, double number);
