//
// Copyright (c) Microsoft. All rights reserved.
// See https://aka.ms/azai/vision/license202012 for the full license information.
//

#pragma once
#include <vision_api_c_common.h>

AZAC_API_(bool) vision_frame_source_handle_is_valid(AZAC_HANDLE source);
AZAC_API vision_frame_source_handle_create(AZAC_HANDLE* source, const char* optionName, const char* optionValue, AZAC_HANDLE format, const char* formatNamespace);
AZAC_API vision_frame_source_handle_release(AZAC_HANDLE source);

AZAC_API vision_frame_source_properties_handle_get(AZAC_HANDLE source, AZAC_HANDLE* properties);
AZAC_API vision_frame_source_writer_handle_get(AZAC_HANDLE source, AZAC_HANDLE* writer);
AZAC_API vision_frame_source_reader_handle_get(AZAC_HANDLE source, AZAC_HANDLE* reader);

typedef void (*PDATA_NEEDED_CALLBACK_FUNC)(AZAC_HANDLE handle, void* context);
AZAC_API vision_frame_source_callback_set(AZAC_HANDLE source, void* context, PDATA_NEEDED_CALLBACK_FUNC);
AZAC_API vision_frame_source_callback_clear(AZAC_HANDLE source);
