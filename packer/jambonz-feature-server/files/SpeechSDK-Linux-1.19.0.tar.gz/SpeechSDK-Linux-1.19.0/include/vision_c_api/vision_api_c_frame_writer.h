//
// Copyright (c) Microsoft. All rights reserved.
// See https://aka.ms/azai/vision/license202012 for the full license information.
//

#pragma once
#include <vision_api_c_common.h>

AZAC_API_(bool) vision_frame_writer_handle_is_valid(AZAC_HANDLE writer);
AZAC_API vision_frame_writer_handle_release(AZAC_HANDLE writer);

AZAC_API vision_frame_writer_properties_handle_get(AZAC_HANDLE writer, AZAC_HANDLE* properties);

AZAC_API_(uint64_t) vision_frame_writer_pos_get(AZAC_HANDLE writer, uint32_t stream, const char* reserved);
AZAC_API vision_frame_writer_write(AZAC_HANDLE writer, uint32_t stream, const uint8_t* data, size_t size, const char* propName, const char* propValue);
AZAC_API vision_frame_writer_write_with_properties(AZAC_HANDLE writer, uint32_t stream, const uint8_t* data, size_t size, AZAC_HANDLE properties);
AZAC_API vision_frame_writer_property_write(AZAC_HANDLE writer, uint32_t stream, const char* name, const char* value, uint64_t pos, const char* reserved);

AZAC_API vision_frame_writer_close(AZAC_HANDLE writer);
