//
// Copyright (c) Microsoft. All rights reserved.
// See https://aka.ms/azai/vision/license202012 for the full license information.
//

#pragma once
#include <vision_api_c_common.h>

AZAC_API_(bool) vision_result_handle_is_valid(AZAC_HANDLE result);
AZAC_API vision_result_handle_release(AZAC_HANDLE result);

AZAC_API vision_result_properties_handle_get(AZAC_HANDLE result, AZAC_HANDLE* properties);
AZAC_API vision_result_frame_reader_handle_get(AZAC_HANDLE result, AZAC_HANDLE* frameReader);
