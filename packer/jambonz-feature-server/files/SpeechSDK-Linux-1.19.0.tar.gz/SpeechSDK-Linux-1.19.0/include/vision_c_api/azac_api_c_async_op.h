//
// Copyright (c) Microsoft. All rights reserved.
// See https://aka.ms/azai/vision/license202012 for the full license information.
//

#pragma once
#include <azac_api_c_common.h>

// TODO: TFS#3671215 - Vision: C/C++ azac_api* files are in shared include directory, speech and vision share

AZAC_API_(bool) async_op_handle_is_valid(AZAC_HANDLE asyncOp);
AZAC_API async_op_handle_release(AZAC_HANDLE asyncOp);

AZAC_API async_op_wait_for(AZAC_HANDLE asyncOp, uint32_t milliseconds);
AZAC_API async_op_wait_for_result(AZAC_HANDLE asyncOp, uint32_t milliseconds, AZAC_HANDLE* result);

typedef void (*PASYNC_OP_CALLBACK_FUNC)(AZAC_HANDLE asyncOpCallback, void* context);
AZAC_API async_op_callback_handle_create(AZAC_HANDLE* handle, void* context, PASYNC_OP_CALLBACK_FUNC callback);

AZAC_API_(bool) async_op_callback_handle_is_valid(AZAC_HANDLE asyncOpCallback);
AZAC_API async_op_callback_handle_release(AZAC_HANDLE asyncOpCallback);
