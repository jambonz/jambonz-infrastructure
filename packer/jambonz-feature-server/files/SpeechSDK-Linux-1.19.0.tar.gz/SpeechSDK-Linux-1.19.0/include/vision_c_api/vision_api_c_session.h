//
// Copyright (c) Microsoft. All rights reserved.
// See https://aka.ms/azai/vision/license202012 for the full license information.
//

#pragma once
#include <vision_api_c_common.h>

AZAC_API_(bool) vision_session_handle_is_valid(AZAC_HANDLE session);
AZAC_API vision_session_handle_create(AZAC_HANDLE* session, AZAC_HANDLE createOptions, AZAC_HANDLE source);
AZAC_API vision_session_handle_release(AZAC_HANDLE session);

AZAC_API vision_session_properties_handle_get(AZAC_HANDLE session, AZAC_HANDLE* properties);
AZAC_API vision_session_view_handle_get(AZAC_HANDLE session, AZAC_HANDLE* sessionView);

AZAC_API_(bool) vision_session_view_handle_is_valid(AZAC_HANDLE sessionView);
AZAC_API vision_session_view_handle_create(AZAC_HANDLE* sessionView, AZAC_HANDLE session, const char* viewKind, AZAC_HANDLE viewOptions);
AZAC_API vision_session_view_handle_release(AZAC_HANDLE sessionView);

AZAC_API vision_session_view_properties_handle_get(AZAC_HANDLE sessionView, AZAC_HANDLE* properties);

AZAC_API vision_session_view_single_shot_start(AZAC_HANDLE sessionView, AZAC_HANDLE startOptions, AZAC_HANDLE asyncOpCallback, AZAC_HANDLE* asyncOp);
AZAC_API vision_session_view_single_shot_stop(AZAC_HANDLE sessionView, AZAC_HANDLE stopOptions, AZAC_HANDLE asyncOpCallback, AZAC_HANDLE* asyncOp);

AZAC_API vision_session_view_continuous_start(AZAC_HANDLE sessionView, AZAC_HANDLE startOptions, AZAC_HANDLE asyncOpCallback, AZAC_HANDLE* asyncOp);
AZAC_API vision_session_view_continuous_stop(AZAC_HANDLE sessionView, AZAC_HANDLE stopOptions, AZAC_HANDLE asyncOpCallback, AZAC_HANDLE* asyncOp);

typedef void (*PEVENT_CALLBACK_FUNC)(AZAC_HANDLE handle, const char* name, void* context, AZAC_HANDLE eventArgs);
AZAC_API vision_session_view_event_callback_set(AZAC_HANDLE sessionView, const char* name, void* context, PEVENT_CALLBACK_FUNC callback);
AZAC_API vision_session_view_event_callbacks_clear(AZAC_HANDLE sessionView);
