//
// Copyright (c) Microsoft. All rights reserved.
// See https://aka.ms/csspeech/license201809 for the full license information.
//

#pragma once
#include <speechapi_c_common.h>
#include <azac_api_c_diagnostics.h> // must include after spxdebug.h or speechapi*.h (can NOT be included before)
