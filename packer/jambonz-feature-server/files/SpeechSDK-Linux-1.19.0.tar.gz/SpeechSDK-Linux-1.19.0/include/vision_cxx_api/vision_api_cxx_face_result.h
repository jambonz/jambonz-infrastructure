//
// Copyright (c) Microsoft. All rights reserved.
// See https://aka.ms/azai/vision/license202012 for the full license information.
//

#pragma once
#include <vision_api_cxx_common.h>
#include <vision_api_cxx_details_result_base.h>
#include <vision_api_cxx_face_result_properties.h>
#include <vision_api_cxx_face_result_property.h>
#include <vision_api_cxx_face_result_reason.h>

namespace Azure {
namespace AI {
namespace Vision {
namespace Face {
namespace Results {

/// <summary>
/// Represents the output an AI inferencing operation (e.g. detection, recognition, prediction, ...).
/// </summary>
class FaceResult : private Core::Details::ResultBase<FaceResultReason, FaceResultProperty, FaceResultProperties>
{
private:

    using BaseResult = ResultBase<FaceResultReason, FaceResultProperty, FaceResultProperties>;

public:

    /// <summary>
    /// Destructs an instance of the FaceResult class.
    /// </summary>
    ~FaceResult() = default;

    /// <summary>
    /// Gets the Media/Frame/FrameSet position that generated this result.  Use the Media Source Reader to retrieve the input.
    /// </summary>
    /// <returns>
    /// The position associated with this result.
    /// </returns>
    uint64_t GetAssociatedMediaPosition() const { return BaseResult::GetAssociatedMediaPosition(); }

    /// <summary>
    /// Gets the FrameSet associated with this result.
    /// </summary>
    /// <returns>
    /// The FrameSet associated with this result.
    /// </returns>
    std::vector<std::shared_ptr<Input::Frames::Frame>> GetAssociatedFrameSet()
    {
        auto reader = BaseResult::GetAssociatedFrameSetReader();
        auto pos = GetAssociatedMediaPosition();

        return reader->ReadFrameSet(pos);
    }

    /// <summary>
    /// Gets the unique id for the Session from which this FaceResult originated.
    /// </summary>
    /// <returns>
    /// The Session Id string.
    /// </returns>
    std::string GetSessionId() const { return BaseResult::GetSessionId(); }

    /// <summary>
    /// Gets the unique id for the Session from which this FaceResult originated.
    /// </summary>
    /// <returns>
    /// The Session Id string.
    /// </returns>
    template<class T = std::string> 
    AI::Core::Details::enable_if_w_or_string_t<T> GetSessionId() const { return BaseResult::GetSessionId<T>(); }

    /// <summary>
    /// Gets the unique FaceResult ID for this FaceResult.
    /// </summary>
    /// <returns>
    /// The unique FaceResult Id string.
    /// </returns>
    std::string GetResultId() const { return BaseResult::GetResultId(); }

    /// <summary>
    /// Gets the unique FaceResult ID for this FaceResult.
    /// </summary>
    /// <returns>
    /// The unique FaceResult Id string.
    /// </returns>
    template<class T = std::string> 
    AI::Core::Details::enable_if_w_or_string_t<T> GetResultId() const { return BaseResult::GetResultId<T>(); }

    /// <summary>
    /// Gets the FaceResultReason for generation of this result.
    /// </summary>
    FaceResultReason GetReason() const { return BaseResult::GetReason(FaceResultReason::NoMatch, FaceResultReason::Recognized); }

    /// <summary>
    /// Gets a collection of additional inferencing operation properties.
    /// </summary>
    const FaceResultProperties& Properties;

protected:

    static std::shared_ptr<FaceResult> FromHandle(AZAC_HANDLE handle)
    {
        auto ptr = new FaceResult(handle);
        return std::shared_ptr<FaceResult>(ptr);
    }

    explicit FaceResult(AZAC_HANDLE result) :
        ResultBase(result),
        Properties(GetProperties())
    {
    }

    explicit operator AZAC_HANDLE() { return AI::Core::Details::ProtectedAccess<BaseResult>::HandleFromPtr(this); }

private:

    AZAC_DISABLE_DEFAULT_CTORS(FaceResult);
};

} } } } } // Azure::AI::Vision::Face::Results
