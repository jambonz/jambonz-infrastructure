//
// Copyright (c) Microsoft. All rights reserved.
// See https://aka.ms/azai/vision/license202012 for the full license information.
//

#pragma once
#include <azac_api_cxx_details_property_collection.h>
#include <vision_api_cxx_face_analyzer_create_option.h>
#include <vision_api_cxx_common.h>

namespace Azure {
namespace AI {
namespace Vision {
namespace Face {
namespace Options {

/// <summary>
/// Defines how the face analysis is performed.
/// </summary>
enum class FaceAnalyzerMode
{
    ///<summary>
    /// Faces are detected in each image in isolation, assuming there is no temporal context in-between each image.
    ///</summary>
    DetectFacesOnStaticImages = 1,
    ///<summary>
    /// Faces are tracked across the image-stream, assuming there is temporal context in each subsequent image in the image-stream.
    ///</summary>
    TrackFacesAcrossImageStream
};

/// <summary>
/// Defines the computations that the face analyer should perform.
/// </summary>
enum class FaceAnalyzerCreateOption
{
    ///<summary>
    /// Compute face landmarks.
    ///</summary>
    Landmarks = (int)FaceAnalyzerCreateOptionInternal::Options_Landmarks,
    ///<summary>
    /// Compute face pose.
    ///</summary>
    Pose,
    ///<summary>
    /// Perform facial recognition.
    ///</summary>
    Recognition,
    ///<summary>
    /// Perform liveness detection on face.
    ///</summary>
    Liveness
};

/// <summary>
/// Represents the options and parameters used to initialize a VisionSession instance.
/// </summary>
class FaceAnalyzerCreateOptions
{
public:

    /// <summary>
    /// Defines how the face analysis is performed.
    /// <param name="mode">The face analyzer mode.</param>
    /// </summary>
    void SetFaceAnalysisMode(FaceAnalyzerMode mode)
    {
        m_options->Set(FaceAnalyzerCreateOptionInternal::FaceAnalyzerMode, (int)mode);
    }

    /// <summary>
    /// Defines the computations that the face analyer should perform.
    /// <param name="option">The face analyzer create option.</param>
    /// </summary>
    void SetFaceAnalyzerOptions(FaceAnalyzerCreateOption option)
    {
        m_options->Set((FaceAnalyzerCreateOptionInternal)((int)option), true);
    }

private:

    template<typename Target> using ProtectedAccess = Azure::AI::Core::Details::ProtectedAccess<Target>;
    using PropertyCollection = AI::Core::Details::PropertyCollection<FaceAnalyzerCreateOptionInternal>;
    std::shared_ptr<PropertyCollection> m_options;

public:

    /// <summary>
    /// Initializes a new instance of the FaceAnalyzerCreateOptions class.
    /// </summary>
    /// <returns>The newly created FaceAnalyzerCreateOptions wrapped inside a std::shared_ptr</returns>
    static std::shared_ptr<FaceAnalyzerCreateOptions> Create()
    {
        auto ptr = new FaceAnalyzerCreateOptions();
        return std::shared_ptr<FaceAnalyzerCreateOptions>(ptr);
    }

    /// <summary>
    /// Destructs an instance of the FaceAnalyzerCreateOptions class.
    /// </summary>
    ~FaceAnalyzerCreateOptions() = default;

protected:

    explicit FaceAnalyzerCreateOptions() :
        m_options(PropertyCollection::Create())
    {
    }

    explicit operator AZAC_HANDLE()
    {
        return ProtectedAccess<PropertyCollection>::HandleFromPtr(m_options.get());
    }

private:

    AZAC_DISABLE_COPY_AND_MOVE(FaceAnalyzerCreateOptions);
};

} } } } } // Azure::AI::Vision::Face::Options
