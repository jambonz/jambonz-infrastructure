//
// Copyright (c) Microsoft. All rights reserved.
// See https://aka.ms/azai/vision/license202012 for the full license information.
//

#pragma once
#include <azac_api_cxx_details_property_collection.h>
#include <vision_api_cxx_common.h>
#include <vision_api_cxx_frame_format_properties.h>
#include <vision_api_cxx_frame_format_property.h>
#include <vision_api_c_frame_format.h>

namespace Azure {
namespace AI {
namespace Vision {
namespace Input {
namespace Frames {

/// <summary>
/// Represents a collection of image format properties (e.g. FOURCC, width, height, stride, ...)
/// </summary>
class FrameFormat
{
protected:

    template<typename Target> using ProtectedAccess = AI::Core::Details::ProtectedAccess<Target>;
    AI::Core::Details::PropertyCollection<Frames::FrameFormatProperty, Frames::FrameFormatProperties> m_properties;

public:

    /// <summary>
    /// Initializes a new instance of the FrameFormat class based on a FourCC value.
    /// </summary>
    /// <param name="ch1">FOURCC character 1</param>
    /// <param name="ch2">FOURCC character 2</param>
    /// <param name="ch3">FOURCC character 3</param>
    /// <param name="ch4">FOURCC character 4</param>
    /// <param name="width">The image format's pixel width</param>
    /// <param name="height">The image format's pixel height</param>
    /// <param name="stride">The image format's pixel stride</param>
    /// <returns>The newly created FrameFormat wrapped inside a std::shared_ptr</returns>
    static std::shared_ptr<FrameFormat> CreateFourCCFormat(char ch1, char ch2, char ch3, char ch4, int width = 0, int height = 0, int stride = 0)
    {
        auto properties = AI::Core::Details::PropertyCollection<>::Create();
        properties->Set("frame.format.image.width", std::to_string(width));
        properties->Set("frame.format.image.height", std::to_string(height));
        AZAC_IFTRUE(stride > 0, properties->Set("frame.format.image.stride", std::to_string(stride)));

        AZAC_HANDLE handle = AZAC_HANDLE_INVALID;
        AZAC_HANDLE propertiesHandle = ProtectedAccess<AI::Core::Details::PropertyCollectionBase<>>::HandleFromPtr(properties.get());
        AZAC_THROW_ON_FAIL(vision_frame_format_handle_create(&handle, ch1, ch2, ch3, ch4, propertiesHandle));
        return FromHandle(handle);
    }

    /// <summary>
    /// Initializes a new instance of the FrameFormat class for uncompressed 32bit ARGB images.
    /// </summary>
    /// <param name="bitsPerPixel">The image format's bits per pixel (e.g. 8, 16, 24, 32, ...)</param>
    /// <param name="width">The image format's pixel width (e.g. 640)</param>
    /// <param name="height">The image format's pixel height (e.g. 480)</param>
    /// <param name="stride">The image format's pixel stride</param>
    /// <returns>The newly created FrameFormat wrapped inside a std::shared_ptr</returns>
    static std::shared_ptr<FrameFormat> CreateRGBFormat(int bitsPerPixel, int width, int height, int stride = 0)
    {
        auto format = CreateFourCCFormat('R', 'G', 'B', ' ', width, height, stride);
        format->m_properties.Set("frame.format.image.bits.per.pixel", std::to_string(bitsPerPixel));
        return format;
    }

    /// <summary>
    /// Destructs an instance of the FrameFormat class.
    /// </summary>
    virtual ~FrameFormat()
    {
        if (vision_frame_format_handle_is_valid(m_format))
        {
            ::vision_frame_format_handle_release(m_format);
            m_format = AZAC_HANDLE_INVALID;
        }
    };

    /// <summary>
    /// Gets the image format's FOURCC value
    /// </summary>
    /// <returns>
    /// The FOURCC format code as a string
    /// </returns>
    std::string GetFourCC() const
    {
        return m_properties.Get("frame.format.image.fourcc");
    }

    /// <summary>
    /// Gets the image format's FOURCC value
    /// </summary>
    /// <param name="ch1">Pointer to char to receive FOURCC character 1</param>
    /// <param name="ch2">Pointer to char to receive FOURCC character 2</param>
    /// <param name="ch3">Pointer to char to receive FOURCC character 3</param>
    /// <param name="ch4">Pointer to char to receive FOURCC character 4</param>
    void GetFourCC(char* ch1, char* ch2, char* ch3, char* ch4) const
    {
        auto code = m_properties.Get("frame.format.image.fourcc.1");
        *ch1 = code[0];
        code = m_properties.Get("frame.format.image.fourcc.2");
        *ch2 = code[0];
        code = m_properties.Get("frame.format.image.fourcc.3");
        *ch3 = code[0];
        code = m_properties.Get("frame.format.image.fourcc.4");
        *ch4 = code[0];
    }

    /// <summary>
    /// Gets the image format's pixel width.
    /// </summary>
    /// <returns>
    /// The image pixel width.
    /// </returns>
    int GetWidth() const
    {
        auto width = m_properties.Get("frame.format.image.width");
        return std::stoi(width);
    }

    /// <summary>
    /// Gets the image format's pixel height.
    /// </summary>
    /// <returns>
    /// The image pixel height.
    /// </returns>
    int GetHeight() const
    {
        auto height = m_properties.Get("frame.format.image.height");
        return std::stoi(height);
    }

    /// <summary>
    /// Gets the image format's pixel stride.
    /// </summary>
    /// <returns>
    /// The image pixel stride.
    /// </returns>
    int GetStride() const
    {
        auto width = m_properties.Get("frame.format.image.stride");
        return std::stoi(width);
    }

    /// <summary>
    /// Sets the image format's bits per pixel value.
    /// </summary>
    /// <param name="bitsPerPixel">The image's bits per pixel value.</param>
    void SetBitsPerPixel(int bitsPerPixel)
    {
        m_properties.Set("frame.format.image.bits.per.pixel", std::to_string(bitsPerPixel));
    }

    /// <summary>
    /// Gets the image format's bits per pixel value.
    /// </summary>
    /// <returns>
    /// The image's bits per pixel value.
    /// </returns>
    int GetBitsPerPixel() const
    {
        auto bitsPerPixel = m_properties.Get("frame.format.image.bits.per.pixel");
        return std::stoi(bitsPerPixel);
    }

    /// <summary>
    /// Gets a collection of additional FrameFormat properties.
    /// </summary>
    FrameFormatProperties& Properties;

protected:

    static std::shared_ptr<FrameFormat> FromHandle(AZAC_HANDLE handle)
    {
        auto ptr = new FrameFormat(handle);
        return std::shared_ptr<FrameFormat>(ptr);
    }

    explicit FrameFormat(AZAC_HANDLE format) :
        m_properties(format, [](auto handle, auto* properties) { return vision_frame_format_properties_handle_get(handle, properties); }),
        Properties(m_properties),
        m_format(format)
    {
    }

    explicit operator AZAC_HANDLE() { return m_format; }

private:

    AZAC_DISABLE_DEFAULT_CTORS(FrameFormat);

    AZAC_HANDLE m_format;
};

} } } } } // Azure::AI::Vision::Input::Frames
