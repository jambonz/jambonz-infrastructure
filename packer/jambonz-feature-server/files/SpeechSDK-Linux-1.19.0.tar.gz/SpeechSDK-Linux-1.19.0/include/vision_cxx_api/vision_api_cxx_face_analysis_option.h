//
// Copyright (c) Microsoft. All rights reserved.
// See https://aka.ms/azai/vision/license202012 for the full license information.
//

#pragma once
#include <vision_api_cxx_common.h>

namespace Azure {
namespace AI {
namespace Vision {
namespace Face {
namespace Options {

enum class FaceAnalysisOption
{
    FaceSelectionMode = 1,
    RecognitionSearchScope_PersonGroupId,
    RecognitionSearchScope_PersonIds,
    RecognitionSearchScope_DynamicPersonGroupId,
    RecognitionSearchScope_RecognitionModel,
    RecognitionSearchScope_Frame,
    AdvancedOption_RecognitionThreshold,
    AdvancedOption_PoseThreshold_Yaw,
    AdvancedOption_PoseThreshold_Pitch,
    AdvancedOption_PoseThreshold_Roll,
    AdvancedOption_FaceSizeRatioThreshold,
    AdvancedOption_LivenessOperationMode,
    AdvancedOption_WaitForFaceTrackingTimeoutDuringAnalyzeOnceInMilliSeconds,
    AdvancedOption_WaitForFaceTrackingTimeoutDuringAnalyzeOnceInFrames
};

} } } } } // Azure::AI::Vision::Face::Options

PRIVATE_PROPERTY_COLLECTION_STATICS(Azure::AI::Vision::Face::Options::FaceAnalysisOption, "face.analyzer.method_option")
