//
// Copyright (c) Microsoft. All rights reserved.
// See https://aka.ms/azai/vision/license202012 for the full license information.
//

#pragma once
#include <azac_api_cxx_details_json.h>
#include <vision_api_cxx_common.h>
#include <vision_api_cxx_details_result_base.h>
#include <vision_api_cxx_face_result_properties.h>
#include <vision_api_cxx_face_result_property.h>
#include <vision_api_cxx_face_result_reason.h>

namespace Azure {
namespace AI {
namespace Vision {
namespace Face {
namespace Results {


struct Rect2DInt
{
    int64_t Left = 0, Top = 0;
    int64_t Width = 0, Height = 0;
};

struct Landmark
{
    std::string Name;
    double X = 0;
    double Y = 0;
};

struct HeadPose
{
    float Pitch = 0;
    float Yaw = 0;
    float Roll = 0;
};

enum class RecognitionStatus
{
    NotComputed,
    Failed,
    NotRecognized,
    Recognized
};

enum class RecognitionFailureReason
{
    None,
    GenericFailure,
    FaceNotFrontal,
    FaceEyeRegionNotVisible,
    ExcessiveFaceBrightness,
    ExcessiveImageBlurDetected
};

enum class NotRecognizedReason
{
    None,
    MaxAttemptsReached,
    TimedOut,
};

struct RecognitionResult
{
    std::string RecognizedIdentifier;
    float Confidence;
    RecognitionStatus Status;
    RecognitionFailureReason FailureReason;
    NotRecognizedReason NotRecoReason;
};

enum class LivenessStatus
{
    NotComputed,
    Failed,
    Live,
    Spoof
};

enum class LivenessFailureReason
{
    None,
    GenericFailure,
    FaceMouthRegionNotVisible,
    FaceEyeRegionNotVisible,
    ExcessiveImageBlurDetected,
    ExcessiveFaceBrightness,
    FaceWithMaskDetected,
    ActionNotPerformed,
    TimedOut
};

struct LivenessResult
{
    LivenessStatus Status;
    LivenessFailureReason FailureReason;
};

enum class MaskStatus
{
    NotComputed,
    NoMask,
    FaceMask,
    OtherMask
};

struct MaskResult
{
    float Confidence;
    MaskStatus Status;
};

enum class GlassStatus
{
    NotComputed,
    NoGlasses,
    ReadingGlasses,
    Sunglasses
};

struct GlassResult
{
    float Confidence;
    GlassStatus Status;
};

struct AnalyzedResults
{
    RecognitionResult Recognition;
    LivenessResult Liveness;
    MaskResult Mask;
    GlassResult Glass;
};

struct AnalyzedFace
{
    std::string FaceUuid; // or guid?
    Rect2DInt BoundingBox;
    std::map<std::string, Landmark> Landmarks;
    HeadPose Pose;
    AnalyzedResults Results;

    std::map<std::string, std::string> Properties;

    // std::shared_ptr<Face> faceptr = std::make_shared<Face>();
    // (*faceptr)->ParseFrom(...)
    AnalyzedFace& ParseFrom(AI::Core::Details::Json::JsonValue jsonReaderFace)
    {
        FaceUuid = jsonReaderFace["UUID"].AsString();
        auto attributes = jsonReaderFace["Attributes"];
        for (int a = 0; a < attributes.Count(); ++a)
        {
            auto attribute = attributes[a];
            if (0 == attribute["QualityFilterFailureReason"].AsInt())
            {
                auto const result = attribute["Result"];
                std::string const type = attribute["Type"].AsString();
                if (type == "BoundingBox")
                {
                    BoundingBox.Left = result["Left"].AsInt();
                    BoundingBox.Top = result["Top"].AsInt();
                    BoundingBox.Width = result["Width"].AsInt();
                    BoundingBox.Height = result["Height"].AsInt();
                }
                else if (type == "FaceIdentity")
                {
                    Results.Recognition.Confidence = result["Confidence"].AsFloat();
                    Results.Recognition.RecognizedIdentifier = result["PersonId"].AsString();
                    std::string status(attribute["Status"].AsString());
                    Results.Recognition.Status
                        = status == "0" /*OK*/ ? RecognitionStatus::Recognized
                        : status == "1" /*Error*/ ? RecognitionStatus::Failed
                        : status == "2" /*NotFound*/ ? RecognitionStatus::NotRecognized
                        : status == "3" /*MissingDependency*/ ? RecognitionStatus::Failed
                        : /*status == "4" QualityCheckFailed*/ RecognitionStatus::NotRecognized;
                }
                else if (type == "HeadPose")
                {
                    Pose.Pitch = result["Pitch"].AsFloat();
                    Pose.Yaw = result["Yaw"].AsFloat();
                    Pose.Roll = result["Roll"].AsFloat();
                }
                // else ...
            }
        }

        return *this;
    }
};


/// <summary>
/// Represents the output an AI inferencing operation (e.g. detection, recognition, prediction, ...).
/// </summary>
class FaceAnalyzedResult : public Core::Details::ResultBase<FaceResultReason, FaceResultProperty, FaceResultProperties>
{
private:

    using BaseResult = ResultBase<FaceResultReason, FaceResultProperty, FaceResultProperties>;

public:

    /// <summary>
    /// Destructs an instance of the FaceAnalyzedResult class.
    /// </summary>
    ~FaceAnalyzedResult() = default;

    /// <summary>
    /// Gets the Media/Frame/FrameSet position that generated this result.  Use the Media Source Reader to retrieve the input.
    /// </summary>
    /// <returns>
    /// The position associated with this result.
    /// </returns>
    uint64_t GetAssociatedMediaPosition() const { return BaseResult::GetAssociatedMediaPosition(); }

    /// <summary>
   /// Gets the FrameSet associated with this result.
   /// </summary>
   /// <returns>
   /// The FrameSet associated with this result.
   /// </returns>
    std::vector<std::shared_ptr<Input::Frames::Frame>> GetAssociatedFrameSet()
    {
        auto reader = BaseResult::GetAssociatedFrameSetReader();
        auto pos = GetAssociatedMediaPosition();

        return reader->ReadFrameSet(pos);
    }

    /// <summary>
    /// Gets the unique id for the Session from which this FaceAnalyzedResult originated.
    /// </summary>
    /// <returns>
    /// The Session Id string.
    /// </returns>
    std::string GetSessionId() const { return BaseResult::GetSessionId(); }

    /// <summary>
    /// Gets the unique id for the Session from which this FaceAnalyzedResult originated.
    /// </summary>
    /// <returns>
    /// The Session Id string.
    /// </returns>
    template<class T = std::string> 
    AI::Core::Details::enable_if_w_or_string_t<T> GetSessionId() const { return BaseResult::GetSessionId<T>(); }

    /// <summary>
    /// Gets the unique FaceAnalyzedResult ID for this FaceAnalyzedResult.
    /// </summary>
    /// <returns>
    /// The unique FaceAnalyzedResult Id string.
    /// </returns>
    std::string GetResultId() const { return BaseResult::GetResultId(); }

    /// <summary>
    /// Gets the unique FaceAnalyzedResult ID for this FaceAnalyzedResult.
    /// </summary>
    /// <returns>
    /// The unique FaceAnalyzedResult Id string.
    /// </returns>
    template<class T = std::string> 
    AI::Core::Details::enable_if_w_or_string_t<T> GetResultId() const { return BaseResult::GetResultId<T>(); }

    /// <summary>
    /// Gets the FaceResultReason for generation of this result.
    /// </summary>
    FaceResultReason GetReason() const { return BaseResult::GetReason(FaceResultReason::NoMatch, FaceResultReason::Recognized); }

    /// <summary>
    /// Gets a collection of additional inferencing operation properties.
    /// </summary>
    const FaceResultProperties& Properties;

    /// <summary>
    /// Gets the tracked collection of faces with their current attributes
    /// </summary>
    std::vector<std::shared_ptr<AnalyzedFace>> GetFaces() const
    {
        auto insightsJson = Properties.Get("insightsJson");
        auto parsedFaces = AI::Core::Details::Json::JsonValue::Parse(insightsJson.c_str(), insightsJson.size());
        std::vector<std::shared_ptr<AnalyzedFace>> faces;
        for (int i = 0; i < parsedFaces.Count(); i++)
        {
            std::shared_ptr<AnalyzedFace> faceptr = std::make_shared<AnalyzedFace>();
            (*faceptr).ParseFrom(parsedFaces[i]);
            faces.push_back(faceptr);
        }

        return faces;
    }

protected:

    static std::shared_ptr<FaceAnalyzedResult> FromHandle(AZAC_HANDLE handle)
    {
        auto ptr = new FaceAnalyzedResult(handle);
        return std::shared_ptr<FaceAnalyzedResult>(ptr);
    }

    explicit FaceAnalyzedResult(AZAC_HANDLE result) :
        ResultBase(result),
        Properties(GetProperties())
    {
    }

    explicit operator AZAC_HANDLE() { return AI::Core::Details::ProtectedAccess<BaseResult>::HandleFromPtr(this); }

private:

    AZAC_DISABLE_DEFAULT_CTORS(FaceAnalyzedResult);
};

} } } } } // Azure::AI::Vision::Face::Results
