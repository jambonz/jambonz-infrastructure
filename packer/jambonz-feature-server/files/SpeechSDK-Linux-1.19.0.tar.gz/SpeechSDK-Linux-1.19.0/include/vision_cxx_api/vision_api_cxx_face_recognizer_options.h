//
// Copyright (c) Microsoft. All rights reserved.
// See https://aka.ms/azai/vision/license202012 for the full license information.
//

#pragma once
#include <azac_api_cxx_details_property_collection.h>
#include <vision_api_cxx_common.h>
#include <vision_api_cxx_face_recognizer_option.h>

namespace Azure {
namespace AI {
namespace Vision {
namespace Face {
namespace Options {

/// <summary>
/// Represents the options and parameters used to initialize a VisionSession instance.
/// </summary>
class FaceRecognizerOptions
{
public:

    /// <summary>
    /// Represents advanced options and parameters used to initialize a VisionSession instance.
    /// </summary>
    class AdvancedOptions
    {
    private:

        template<typename Target> using ProtectedAccess = Azure::AI::Core::Details::ProtectedAccess<Target>;
        using PropertyCollection = AI::Core::Details::PropertyCollection<Options::FaceRecognizerOption>;
        std::shared_ptr<PropertyCollection> m_options;

    public:

        /// <summary>
        /// Sets the string value for the specified option.
        /// </summary>
        /// <param name="key">The string value's key</param>
        /// <param name="value">The new string value</param>
        void Set(FaceRecognizerOption option, const char* value)
        {
            m_options->Set(option, value);
        }

        /// <summary>
        /// Sets the string value for the specified option.
        /// </summary>
        /// <param name="key">The string value's key</param>
        /// <param name="value">The new string value</param>
        void Set(FaceRecognizerOption option, const wchar_t* value)
        {
            m_options->Set(option, value);
        }

        /// <summary>
        /// Sets the string value for the specified option.
        /// </summary>
        /// <param name="key">The string value's key</param>
        /// <param name="value">The new string value</param>
        void Set(FaceRecognizerOption option, const std::string& value)
        {
            m_options->Set(option, value);
        }

        /// <summary>
        /// Sets the string value for the specified option.
        /// </summary>
        /// <param name="key">The string value's key</param>
        /// <param name="value">The new string value</param>
        void Set(FaceRecognizerOption option, const std::wstring& value)
        {
            m_options->Set(option, value);
        }

        /// <summary>
        /// Sets the property boolean value for the specified key value.
        /// </summary>
        /// <param name="key">The boolean value's key</param>
        /// <param name="value">The new boolean value</param>
        void Set(FaceRecognizerOption option, bool value)
        {
            m_options->Set(option, value);
        }

        /// <summary>
        /// Sets the property integer value for the specified key value.
        /// </summary>
        /// <param name="key">The integer value's key</param>
        /// <param name="value">The new integer value</param>
        void Set(FaceRecognizerOption option, int value)
        {
            m_options->Set(option, value);
        }

        /// <summary>
        /// Sets the string value for the specified option.
        /// </summary>
        /// <param name="key">The string value's key</param>
        /// <param name="value">The new string value</param>
        void Set(const std::string& option, const char* value)
        {
            m_options->Set(option, value);
        }

        /// <summary>
        /// Sets the string value for the specified option.
        /// </summary>
        /// <param name="key">The string value's key</param>
        /// <param name="value">The new string value</param>
        void Set(const std::wstring& option, const wchar_t* value)
        {
            m_options->Set(option, value);
        }

        /// <summary>
        /// Sets the string value for the specified option.
        /// </summary>
        /// <param name="key">The string value's key</param>
        /// <param name="value">The new string value</param>
        void Set(const std::string& option, const std::string& value)
        {
            m_options->Set(option, value);
        }

        /// <summary>
        /// Sets the string value for the specified option.
        /// </summary>
        /// <param name="key">The string value's key</param>
        /// <param name="value">The new string value</param>
        void Set(const std::wstring& option, const std::wstring& value)
        {
            m_options->Set(option, value);
        }

        /// <summary>
        /// Sets the property boolean value for the specified key value.
        /// </summary>
        /// <param name="key">The boolean value's key</param>
        /// <param name="value">The new boolean value</param>
        void Set(const std::string& option, bool value)
        {
            m_options->Set(option, value);
        }

        /// <summary>
        /// Sets the property boolean value for the specified key value.
        /// </summary>
        /// <param name="key">The boolean value's key</param>
        /// <param name="value">The new boolean value</param>
        void Set(const std::wstring& option, bool value)
        {
            m_options->Set(option, value);
        }

        /// <summary>
        /// Sets the property integer value for the specified key value.
        /// </summary>
        /// <param name="key">The integer value's key</param>
        /// <param name="value">The new integer value</param>
        void Set(const std::string& option, int value)
        {
            m_options->Set(option, value);
        }

        /// <summary>
        /// Sets the property integer value for the specified key value.
        /// </summary>
        /// <param name="key">The integer value's key</param>
        /// <param name="value">The new integer value</param>
        void Set(const std::wstring& option, int value)
        {
            m_options->Set(option, value);
        }

        // TODO: TFS#3664110 - Vision: Face Result APIs, family specific recognizer options in C++

    protected:

        static std::shared_ptr<AdvancedOptions> Create()
        {
            auto ptr = new AdvancedOptions();
            return std::shared_ptr<AdvancedOptions>(ptr);
        }

        explicit AdvancedOptions() :
            m_options(PropertyCollection::Create())
        {
        }

        explicit operator AZAC_HANDLE()
        {
            return ProtectedAccess<PropertyCollection>::HandleFromPtr(m_options.get());
        }

    private:

        AZAC_DISABLE_COPY_AND_MOVE(AdvancedOptions);
    };

private:

    template<typename Target> using ProtectedAccess = Azure::AI::Core::Details::ProtectedAccess<Target>;

    std::shared_ptr<AdvancedOptions> m_options;

public:

    /// <summary>
    /// Initializes a new instance of the FaceRecognizerOptions class.
    /// </summary>
    /// <returns>The newly created FaceRecognizerOptions wrapped inside a std::shared_ptr</returns>
    static std::shared_ptr<FaceRecognizerOptions> Create()
    {
        auto ptr = new FaceRecognizerOptions();
        return std::shared_ptr<FaceRecognizerOptions>(ptr);
    }

    /// <summary>
    /// Destructs an instance of the FaceRecognizerOptions class.
    /// </summary>
    ~FaceRecognizerOptions() = default;

    /// <summary>
    /// Advanced options and parameters
    /// </summary>
    AdvancedOptions& Advanced;

    // TODO: TFS#3664110 - Vision: Face Result APIs, family specific recognizer options in C++

protected:

    explicit FaceRecognizerOptions() :
        m_options(ProtectedAccess<AdvancedOptions>::Create()),
        Advanced(*m_options.get())
    {
    }

    explicit operator AZAC_HANDLE()
    {
        return ProtectedAccess<AdvancedOptions>::HandleFromPtr(m_options.get());
    }

private:

    AZAC_DISABLE_COPY_AND_MOVE(FaceRecognizerOptions);
};

} } } } } // Azure::AI::Vision::Face::Options
