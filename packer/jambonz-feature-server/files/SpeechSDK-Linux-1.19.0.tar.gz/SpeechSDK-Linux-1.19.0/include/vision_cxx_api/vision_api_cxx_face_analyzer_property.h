//
// Copyright (c) Microsoft. All rights reserved.
// See https://aka.ms/azai/vision/license202012 for the full license information.
//

#pragma once
#include <vision_api_cxx_common.h>

namespace Azure {
namespace AI {
namespace Vision {
namespace Face {

enum class FaceAnalyzerProperty
{
};

} } } } // Azure::AI::Vision::Face

PRIVATE_PROPERTY_COLLECTION_STATICS(Azure::AI::Vision::Face::FaceAnalyzerProperty, "face.analyzer")
