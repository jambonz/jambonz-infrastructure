//
// Copyright (c) Microsoft. All rights reserved.
// See https://aka.ms/azai/vision/license202012 for the full license information.
//

#pragma once
#include <azac_api_cxx_details_property_collection.h>
#include <vision_api_cxx_common.h>
#include <vision_api_cxx_frame.h>
#include <vision_api_cxx_frame_reader.h>
#include <vision_api_cxx_frameset_reader.h>
#include <vision_api_c_frame_source.h>
#include <vision_api_c_result.h>


namespace Azure {
namespace AI {
namespace Vision {
namespace Core {
namespace Details {

template<typename TReason, typename TPropKey, typename TProperties = AI::Core::Details::PropertyCollectionBase<TPropKey>>
class ResultBase
{
private:

    template<typename Target> using ProtectedAccess = AI::Core::Details::ProtectedAccess<Target>;
    AI::Core::Details::PropertyCollection<TPropKey, TProperties> m_properties;

public:

    ~ResultBase()
    {
        if (vision_result_handle_is_valid(m_result))
        {
            ::vision_result_handle_release(m_result);
            m_result = AZAC_HANDLE_INVALID;
        }
    };

    template<class T = std::string>
    AI::Core::Details::enable_if_w_or_string_t<T> GetSessionId() const
    {
        return AI::Core::Details::to_string<T>(m_properties.Get("session.id", ""));
    }

    template<class T = std::string>
    AI::Core::Details::enable_if_w_or_string_t<T> GetResultId() const
    {
        return AI::Core::Details::to_string<T>(m_properties.Get("result.id", ""));
    }

    uint64_t GetAssociatedMediaPosition() const
    {
        auto property = m_properties.Get("result.pos", "");
        if (property.empty())
        {
            AZAC_THROW_HR(AZAC_ERR_NOT_FOUND);
        }
        return std::stoull(property);
    }

    TReason GetReason(TReason min, TReason max) const
    {
        auto property = m_properties.Get("result.reason", "0");
        auto value = std::stoi(property.c_str());
        AZAC_IFTRUE_THROW_HR(value < static_cast<int>(min) || value > static_cast<int>(max), AZAC_ERR_INVALID_RESULT_REASON);
        return (TReason)value;
    }

    std::shared_ptr<Input::Frames::FrameReader> GetAssociatedFrameReader()
    {
        // A new object is created with each call because there may be a series of frames.  This allows for two different callers
        //  to not interfere with one anothers' read position.
        AZAC_HANDLE frameReaderHandle = AZAC_HANDLE_INVALID;
        if (AZAC_SUCCEEDED(vision_result_frame_reader_handle_get(m_result, &frameReaderHandle)))
        {
            return ProtectedAccess<Input::Frames::FrameReader>::FromHandle(frameReaderHandle);
        }

        return {};
    }

    std::shared_ptr<Input::Frames::FrameSetReader> GetAssociatedFrameSetReader()
    {
        // A new object is created with each call because there may be a series of frames.  This allows for two different callers
        //  to not interfere with one anothers' read position.
        AZAC_HANDLE frameSetReaderHandle = AZAC_HANDLE_INVALID;
        if (AZAC_SUCCEEDED(vision_result_frame_reader_handle_get(m_result, &frameSetReaderHandle)))
        {
            return ProtectedAccess<Input::Frames::FrameSetReader>::FromHandle(frameSetReaderHandle);
        }

        return {};
    }

    const TProperties& GetProperties() const { return m_properties; }

protected:

    explicit ResultBase(AZAC_HANDLE result) :
        m_properties(result, [](auto handle, auto* properties) { return vision_result_properties_handle_get(handle, properties); }),
        m_result(result)
    {
    }

    explicit operator AZAC_HANDLE() { return m_result; }

private:

    AZAC_DISABLE_DEFAULT_CTORS(ResultBase);

    AZAC_HANDLE m_result = AZAC_HANDLE_INVALID;
};

} } } } } // Azure::AI::Vision::Core::Details
