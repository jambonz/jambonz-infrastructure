//
// Copyright (c) Microsoft. All rights reserved.
// See https://aka.ms/azai/vision/license202012 for the full license information.
//

#pragma once
#include <azac_api_cxx_details_property_collection.h>
#include <vision_api_cxx_common.h>
#include <vision_api_cxx_details_session_stopped_details.h>
#include <vision_api_cxx_body_tracking_result.h>
#include <vision_api_cxx_body_tracking_failure_reason.h>
#include <vision_api_cxx_body_tracking_stopped_event_args.h>
#include <vision_api_cxx_body_tracking_stopped_reason.h>

namespace Azure {
namespace AI {
namespace Vision {
namespace Body {
namespace Results {

using namespace Azure::AI::Vision::Body::Events;

/// <summary>
/// Class with additional information about why a Body Tracking session had an error
/// </summary>
class BodyTrackingStopDetails :
    private Core::Details::SessionStoppedDetails<BodyTrackingStoppedReason, BodyTrackingStopDetails, BodyTrackingResult>
{
private:

    using BaseDetails = Core::Details::SessionStoppedDetails<BodyTrackingStoppedReason, BodyTrackingStopDetails, BodyTrackingResult>;

public:

    /// <summary>
    /// Creates an instance of BodyTrackingStopDetails object from the BodyTrackingResult.
    /// </summary>
    /// <param name="args">The arguments from a session that stopped for an error.</param>
    /// <returns>A shared pointer to BodyTrackingStopDetails.</returns>
    static std::shared_ptr<BodyTrackingStopDetails> FromResult(std::shared_ptr<BodyTrackingResult> result)
    {
        return BaseDetails::FromResult(result);
    }

    /// <summary>
    /// Gets the reason for the error
    /// </summary>
    /// <remarks>See BodyTrackingStoppedReason for a list of reasons</remarks>
    /// <returns></returns>
    BodyTrackingStoppedReason GetReason() { return BaseDetails::GetReason(); }

protected:
    static std::shared_ptr<BodyTrackingStopDetails> FromHandle(AZAC_HANDLE handle)
    {
        auto ptr = new BodyTrackingStopDetails(handle);
        return std::shared_ptr<BodyTrackingStopDetails>(ptr);
    }

    explicit BodyTrackingStopDetails(AZAC_HANDLE propertiesHandle)
        : BaseDetails(propertiesHandle) {}

    explicit operator AZAC_HANDLE() { return AI::Core::Details::ProtectedAccess<BodyTrackingStopDetails>::HandleFromPtr(this); }

private:
    AZAC_DISABLE_DEFAULT_CTORS(BodyTrackingStopDetails);
};

} } } } } // Azure::AI::Vision::Body::Results
