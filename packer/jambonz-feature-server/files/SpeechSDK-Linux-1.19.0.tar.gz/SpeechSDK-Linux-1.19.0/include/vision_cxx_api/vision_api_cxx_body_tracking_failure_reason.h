//
// Copyright (c) Microsoft. All rights reserved.
// See https://aka.ms/azai/vision/license202012 for the full license information.
//

#pragma once
#include <vision_api_cxx_common.h>

namespace Azure {
namespace AI {
namespace Vision {
namespace Body {
namespace Results {

/// <summary>
/// Reasons why BodyTracking failed.
/// </summary>
enum class BodyTrackingFailureReason
{
    /// <summary>
    /// Indicates an authentication error.
    /// An authentication error occurs if subscription key or authorization token is invalid, expired,
    /// or does not match the region being used.
    /// </summary>
    AuthenticationFailure = 1,

    /// <summary>
    /// Indicates that one or more recognition parameters are invalid or the audio format is not supported.
    /// </summary>
    BadRequest = 2,

    /// <summary>
    /// Indicates that the number of parallel requests exceeded the number of allowed concurrent transcriptions for the subscription.
    /// </summary>
    TooManyRequests = 3,

    /// <summary>
    /// Indicates that the free subscription used by the request ran out of quota.
    /// </summary>
    Forbidden = 4,

    /// <summary>
    /// Indicates a connection error.
    /// </summary>
    ConnectionFailure = 5,

    /// <summary>
    /// Indicates a time-out error when waiting for response from service.
    /// </summary>
    ServiceTimeout = 6,

    /// <summary>
    /// Indicates that an error is returned by the service.
    /// </summary>
    ServiceError = 7,

    /// <summary>
    /// Indicates that the service is currently unavailable.
    /// </summary>
    ServiceUnavailable = 8,

    /// <summary>
    /// Indicates an unexpected runtime error.
    /// </summary>
    RuntimeError = 9
};

} } } } } // Azure::AI::Vision::Body::Results

