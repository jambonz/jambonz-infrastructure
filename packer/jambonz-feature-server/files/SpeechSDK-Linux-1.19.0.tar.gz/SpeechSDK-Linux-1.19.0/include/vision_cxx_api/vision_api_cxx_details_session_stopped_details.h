//
// Copyright (c) Microsoft. All rights reserved.
// See https://aka.ms/azai/vision/license202012 for the full license information.
//

#pragma once
#include <string>
#include <azac_api_cxx_details_property_collection.h>
#include <vision_api_cxx_common.h>
#include <vision_api_cxx_session_stopped_event_args.h>
#include <vision_api_c_event_args.h>

namespace Azure {
namespace AI {
namespace Vision {
namespace Core {
namespace Details {

/// <summary>
/// Contains detailed information about why an error occurred
/// </summary>
template<typename TReason, typename TDetails, typename TResult>
class SessionStoppedDetails
{
private:

    template<typename Target> using ProtectedAccess = AI::Core::Details::ProtectedAccess<Target>;

    /// <summary>
    /// Enumeration for the error
    /// </summary>
    TReason m_reason;

public:

    /// <summary>
    /// Creates an instance of the correct ErrorDetails object from the event args.
    /// </summary>
    /// <param name="result">The result that was canceled.</param>
    /// <returns>A shared pointer to CancellationDetails.</returns>
    static std::shared_ptr<TDetails> FromResult(std::shared_ptr<TResult> result)
    {
        auto resultHandle = ProtectedAccess<TResult>::HandleFromPtr(result.get());
        AZAC_HANDLE propertiesHandle = AZAC_HANDLE_INVALID;
        AZAC_THROW_ON_FAIL(vision_result_properties_handle_get(resultHandle, &propertiesHandle));

        auto details = ProtectedAccess<TDetails>::FromHandle(propertiesHandle);
        return details;
    }

    /// <summary>
    /// Gets the reason for the error
    /// </summary>
    /// <returns></returns>
    TReason GetReason()
    {
        return m_reason;
    }

protected:
    SessionStoppedDetails(AZAC_HANDLE propsHandle)
    {
        auto properties2 = ProtectedAccess<AI::Core::Details::PropertyCollectionBase<int>>::FromHandle(propsHandle);
        m_reason = (TReason)std::stoi(properties2->Get("session.stopped.reason", "0"));
    }
private:
    AZAC_DISABLE_DEFAULT_CTORS(SessionStoppedDetails);
};

} } } } } // Azure::AI::Vision::Core::Details