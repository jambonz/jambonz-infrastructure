//
// Copyright (c) Microsoft. All rights reserved.
// See https://aka.ms/azai/vision/license202012 for the full license information.
//

#pragma once
#include <future>
#include <azac_api_cxx_details_property_collection.h>
#include <vision_api_cxx_common.h>
#include <vision_api_cxx_event_signal.h>
#include <vision_api_cxx_details_recognizer_base.h>
#include <vision_api_cxx_body_tracker_options.h>
#include <vision_api_cxx_body_tracker_properties.h>
#include <vision_api_cxx_body_tracker_property.h>
#include <vision_api_cxx_body_tracking_result.h>
#include <vision_api_cxx_body_tracking_started_event_args.h>
#include <vision_api_cxx_body_tracking_stopped_event_args.h>
#include <vision_api_cxx_body_tracking_event_args.h>
#include <vision_api_cxx_session.h>
#include <vision_api_cxx_source.h>

namespace Azure {
namespace AI {
namespace Vision {
namespace Body {

// TODO: TFS#3426369 - Vision BT: Ensure C++ methods/classes are doc'd in situ

/// <summary>
/// Represents a set of Vision capabilities used for a finite period of time, with a given set of configuration, input, and options
/// </summary>
/// <remarks>Use BodyTracker::Create(service, input) to instantiate</remarks>
class BodyTracker :
    public std::enable_shared_from_this<BodyTracker>,
    private Core::Details::RecognizerBase<Body::BodyTracker,
        Options::BodyTrackerOptions, Options::BodyTrackerOption,
        Options::BodyTrackerOptions, Options::BodyTrackerOption,
        Body::BodyTrackerProperties, Body::BodyTrackerProperty,
        Results::BodyTrackingResult, Events::BodyTrackingEventArgs,
        Results::BodyTrackingResult, Events::BodyTrackingEventArgs,
        Events::BodyTrackingStartedEventArgs, Events::BodyTrackingStoppedEventArgs>
{
protected:

    friend class Core::Details::RecognizerBase<Body::BodyTracker,
        Options::BodyTrackerOptions, Options::BodyTrackerOption,
        Options::BodyTrackerOptions, Options::BodyTrackerOption,
        Body::BodyTrackerProperties, Body::BodyTrackerProperty,
        Results::BodyTrackingResult, Events::BodyTrackingEventArgs,
        Results::BodyTrackingResult, Events::BodyTrackingEventArgs,
        Events::BodyTrackingStartedEventArgs, Events::BodyTrackingStoppedEventArgs>;
    using BaseRecognizer = Core::Details::RecognizerBase<BodyTracker,
        Options::BodyTrackerOptions, Options::BodyTrackerOption,
        Options::BodyTrackerOptions, Options::BodyTrackerOption,
        Body::BodyTrackerProperties, Body::BodyTrackerProperty,
        Results::BodyTrackingResult, Events::BodyTrackingEventArgs,
        Results::BodyTrackingResult, Events::BodyTrackingEventArgs,
        Events::BodyTrackingStartedEventArgs, Events::BodyTrackingStoppedEventArgs>;

public:

    /// <summary>
    /// Initializes a new instance of the BodyTracker class.
    /// </summary>
    /// <returns>The newly created BodyTracker wrapped inside a std::shared_ptr</returns>
    static std::shared_ptr<BodyTracker> Create(const std::shared_ptr<Service::VisionServiceConfig>& config, const std::shared_ptr<Input::VisionSource>& input, const std::shared_ptr<Options::BodyTrackerOptions>& options = nullptr)
    {
        return BaseRecognizer::Create("body.tracker", config, input, options);
    }

    /// <summary>
    /// Destructs an instance of the BodyTracker class.
    /// </summary>
    virtual ~BodyTracker() { }

    /// <summary>
    /// Gets the unique Session ID for this BodyTracker.
    /// </summary>
    /// <returns>
    /// The Session ID string.
    /// </returns>
    std::string GetSessionId() const { return BaseRecognizer::GetSessionId(); }

    /// <summary>
    /// Gets the unique Session ID for this BodyTracker.
    /// </summary>
    /// <returns>
    /// The Session ID string.
    /// </returns>
    template<class T = std::string>
    AI::Core::Details::enable_if_w_or_string_t<T> GetSessionId() const { return BaseRecognizer::GetSessionId<T>(); }

    /// <summary>
    /// Tracks bodies in one frame.
    /// </summary>
    /// <returns>The newly created BodyTrackingResult wrapped inside a std::shared_ptr</returns>
    std::shared_ptr<Results::BodyTrackingResult> TrackOnce() { return BaseRecognizer::RecognizeOnce(); }

    /// <summary>
    /// Tracks bodies in one frame, asynchronously.
    /// </summary>
    /// <returns>The future BodyTrackingResult wrapped inside a std::future<std::shared_ptr<>></returns>
    std::future<std::shared_ptr<Results::BodyTrackingResult>> TrackOnceAsync() { return BaseRecognizer::RecognizeOnceAsync(); }

    /// <summary>
    /// Starts continuously tracking bodies.
    /// </summary>
    void StartContinuousBodyTracking() { BaseRecognizer::StartContinuousRecognition(); }

    /// <summary>
    /// Starts continuously tracking bodies.
    /// </summary>
    /// <returns>A std::future<void> to be completed once continuous recognition has started</returns>
    std::future<void> StartContinuousBodyTrackingAsync() { return BaseRecognizer::StartContinuousRecognitionAsync(); }

    /// <summary>
    /// Stops body tracking
    /// </summary>
    void StopContinuousBodyTracking() { BaseRecognizer::StopContinuousRecognition(); }

    /// <summary>
    /// Stops body tracking, asynchronously.
    /// </summary>
    /// <returns>A std::future<void> to be completed once continuous recognition has stopped</returns>
    std::future<void> StopContinuousBodyTrackingAsync() { return BaseRecognizer::StopContinuousRecognitionAsync(); }

    /// <summary>
    /// Stops body tracking, asynchronously.
    /// </summary>
    void StopBodyTrackingOnce() { BaseRecognizer::StopRecognitionOnce(); }

    /// <summary>
    /// Stops body tracking, asynchronously.
    /// </summary>
    /// <returns>A std::future<void> to be completed once recognition has stopped</returns>
    std::future<void> StopBodyTrackingOnceAsync() { return BaseRecognizer::StopRecognitionOnceAsync(); }

    /// <summary>
    /// Waits for recognition to stop
    /// </summary>
    /// <returns>true if the session stopped, false if not stopped after, the default timeout</returns>
    /// <remarks>WaitForStop does not initiate stopping. Call StopContinuousRecognition or similar to initiate stopping</remarks>
    bool WaitForStop() { return BaseRecognizer::WaitForStop(); }

    /// <summary>
    /// Waits for recognition to stop
    /// </summary>
    /// <returns>true if the session stopped, false if not stopped after timeout</returns>
    /// <remarks>WaitForStop does not initiate stopping. Call StopContinuousRecognition or similar to initiate stopping</remarks>
    bool WaitForStop(const std::chrono::milliseconds& timeout) { return BaseRecognizer::WaitForStop(timeout); }

    /// <summary>
    /// Waits for recognition to stop
    /// </summary>
    /// <returns>std::future<bool> representing the session stopping</returns>
    /// <remarks>WaitForStop does not initiate stopping. Call StopContinuousRecognition or similar to initiate stopping</remarks>
    std::future<void> WaitForStopAsync() { return BaseRecognizer::WaitForStopAsync(); }

    /// <summary>
    /// Signal for events indicating body tracking starts..
    /// </summary>
    Core::Events::EventSignal<const Events::BodyTrackingStartedEventArgs&>& Started;

    /// <summary>
    /// Signal for events indicating body tracking is stopped.
    /// </summary>
    Core::Events::EventSignal<const Events::BodyTrackingStoppedEventArgs&>& Stopped;

    /// <summary>
    /// Signal for events containing intermedia recognition operations.
    /// </summary>
    Core::Events::EventSignal<const Events::BodyTrackingEventArgs&>& Recognizing;

    /// <summary>
    /// Signal for events containing recognition operations.
    /// </summary>
    Core::Events::EventSignal<const Events::BodyTrackingEventArgs&>& Recognized;

    /// <summary>
    /// Gets a collection of additional inferencing operation properties.
    /// </summary>
    Body::BodyTrackerProperties& Properties;

protected:

    explicit BodyTracker(AZAC_HANDLE view) :
        RecognizerBase(view),
        Started(m_SessionStarted),
        Stopped(m_SessionStopped),
        Recognizing(m_Recognizing),
        Recognized(m_Recognized),
        Properties(GetProperties())
    {
    }

private:

    AZAC_DISABLE_DEFAULT_CTORS(BodyTracker);
};

} } } } // Azure::AI::Vision::Body
