//
// Copyright (c) Microsoft. All rights reserved.
// See https://aka.ms/azai/vision/license202012 for the full license information.
//

#pragma once
#include <vision_api_cxx_common.h>
#include <vision_api_cxx_details_result_base.h>
#include <vision_api_cxx_face_analyzed_result.h>
#include <vision_api_cxx_face_analyzing_result.h>

namespace Azure {
namespace AI {
namespace Vision {
namespace Face {
namespace Results {


enum class FaceTrackingState
{
    None,
    New,
    Tracked,
    Lost
};

enum class NeededActionItem
{
    None,
    BrightenDisplay,
    DarkenDisplay,
    LockFocus,
    LockExposure,
    UnlockExposure,
    UnlockExposureAndFocus
};

struct NeededAction
{
    NeededActionItem ActionItem;
    void SetAsCompleted() { /* todo: [seana] add something here! May need more context in struct. */ }
};

enum class UserFeedback
{
    None,
    LookAtCamera,
    FaceNotCentered,
    MoveCloser,
    MoveBack,
    TooMuchMovement
};

enum class AnalyzingWarning
{
    None,
    TooBlurry,
    FaceTooDark,
    FaceTooBright,
    LowFidelityFaceRegion,
    LowFramerate
};


struct AnalyzingFace : public AnalyzedFace
{
    FaceTrackingState TrackingState;

    NeededAction Action;
    UserFeedback Feedback;
    AnalyzingWarning Warning;

    AnalyzingFace& ParseFrom(AI::Core::Details::Json::JsonValue jsonReaderFace, FaceTrackingState trackingState = FaceTrackingState::None)
    {
        AnalyzedFace::ParseFrom(jsonReaderFace);
        TrackingState = trackingState;

        auto attributes = jsonReaderFace["Attributes"];
        for (int a = 0; a < attributes.Count(); ++a)
        {
            auto attribute = attributes[a];
            if (0 == attribute["QualityFilterFailureReason"].AsInt())
            {
                auto const result = attribute["Result"];
                std::string const type = attribute["Type"].AsString();
                if (type == "something")
                {
                    //result["field"];
                }
                else if (type == "")
                {
                }
                //attribute["Result"]
            }
        }
        // add LivenessResult parsing
        // add MaskReulst parsing
        // add GlassResult parsing
        return *this;
    }
};

/// <summary>
/// Represents the output an AI inferencing operation (e.g. detection, recognition, prediction, ...).
/// </summary>
class FaceAnalyzingResult : public Core::Details::ResultBase<FaceResultReason, FaceResultProperty, FaceResultProperties>
{
private:

    using BaseResult = ResultBase<FaceResultReason, FaceResultProperty, FaceResultProperties>;

public:

    /// <summary>
    /// Destructs an instance of the FaceAnalyzingResult class.
    /// </summary>
    ~FaceAnalyzingResult() = default;

    /// <summary>
    /// Gets the Media/Frame/FrameSet position that generated this result.  Use the Media Source Reader to retrieve the input.
    /// </summary>
    /// <returns>
    /// The position associated with this result.
    /// </returns>
    uint64_t GetAssociatedMediaPosition() const { return BaseResult::GetAssociatedMediaPosition(); }

    /// <summary>
    /// Gets the FrameReader associated with this result.
    /// </summary>
    /// <returns>
    /// The FrameReader associated with this result.
    /// </returns>
    std::shared_ptr<Input::Frames::FrameReader> GetAssociatedFrameReader() { return BaseResult::GetAssociatedFrameReader(); }

    /// <summary>
    /// Gets the FrameSetReader associated with this result.
    /// </summary>
    /// <returns>
    /// The FrameSetReader associated with this result.
    /// </returns>
    std::shared_ptr<Input::Frames::FrameSetReader> GetAssociatedFrameSetReader() { return BaseResult::GetAssociatedFrameSetReader(); }

    /// <summary>
    /// Gets the unique id for the Session from which this FaceAnalyzingResult originated.
    /// </summary>
    /// <returns>
    /// The Session Id string.
    /// </returns>
    std::string GetSessionId() const { return BaseResult::GetSessionId(); }

    /// <summary>
    /// Gets the unique id for the Session from which this FaceAnalyzingResult originated.
    /// </summary>
    /// <returns>
    /// The Session Id string.
    /// </returns>
    template<class T = std::string> 
    AI::Core::Details::enable_if_w_or_string_t<T> GetSessionId() const { return BaseResult::GetSessionId<T>(); }

    /// <summary>
    /// Gets the unique FaceAnalyzingResult ID for this FaceAnalyzingResult.
    /// </summary>
    /// <returns>
    /// The unique FaceAnalyzingResult Id string.
    /// </returns>
    std::string GetResultId() const { return BaseResult::GetResultId(); }

    /// <summary>
    /// Gets the unique FaceAnalyzingResult ID for this FaceAnalyzingResult.
    /// </summary>
    /// <returns>
    /// The unique FaceAnalyzingResult Id string.
    /// </returns>
    template<class T = std::string> 
    AI::Core::Details::enable_if_w_or_string_t<T> GetResultId() const { return BaseResult::GetResultId<T>(); }

    /// <summary>
    /// Gets the FaceResultReason for generation of this result.
    /// </summary>
    FaceResultReason GetReason() const { return BaseResult::GetReason(FaceResultReason::NoMatch, FaceResultReason::Recognized); }

    /// <summary>
    /// Gets a collection of additional inferencing operation properties.
    /// </summary>
    const FaceResultProperties& Properties;

    /// <summary>
    /// Gets the tracked collection of faces with their current attributes
    /// </summary>
    std::vector<std::shared_ptr<AnalyzingFace>> GetFaces() const
    {
        auto newFacesJson = Properties.Get("newFaces");
        auto newFacesParsed = AI::Core::Details::Json::JsonValue::Parse(newFacesJson.c_str(), newFacesJson.size());
        std::vector<std::shared_ptr<AnalyzingFace>> faces;
        for (int i = 0; i < newFacesParsed.Count(); i++)
        {
            std::shared_ptr<AnalyzingFace> faceptr = std::make_shared<AnalyzingFace>();
            (*faceptr).ParseFrom(newFacesParsed[i], FaceTrackingState::New);
            faces.push_back(faceptr);
        }

        auto trackedFacesJson = Properties.Get("trackedFaces");
        auto trackedFacesParsed = AI::Core::Details::Json::JsonValue::Parse(trackedFacesJson.c_str(), trackedFacesJson.size());
        for (int i = 0; i < trackedFacesParsed.Count(); i++)
        {
            std::shared_ptr<AnalyzingFace> faceptr = std::make_shared<AnalyzingFace>();
            (*faceptr).ParseFrom(trackedFacesParsed[i], FaceTrackingState::Tracked);
            faces.push_back(faceptr);
        }

        auto lostFacesJson = Properties.Get("lostFaces");
        auto lostFacesParsed = AI::Core::Details::Json::JsonValue::Parse(lostFacesJson.c_str(), lostFacesJson.size());
        for (int i = 0; i < lostFacesParsed.Count(); i++)
        {
            std::shared_ptr<AnalyzingFace> faceptr = std::make_shared<AnalyzingFace>();
            (*faceptr).ParseFrom(lostFacesParsed[i], FaceTrackingState::Lost);
            faces.push_back(faceptr);
        }

        return faces;
    }

protected:

    static std::shared_ptr<FaceAnalyzingResult> FromHandle(AZAC_HANDLE handle)
    {
        auto ptr = new FaceAnalyzingResult(handle);
        return std::shared_ptr<FaceAnalyzingResult>(ptr);
    }

    explicit FaceAnalyzingResult(AZAC_HANDLE result) :
        BaseResult(result),
        Properties(GetProperties())
    {
    }

    explicit operator AZAC_HANDLE() { return AI::Core::Details::ProtectedAccess<BaseResult>::HandleFromPtr(this); }

private:

    AZAC_DISABLE_DEFAULT_CTORS(FaceAnalyzingResult);
};

} } } } } // Azure::AI::Vision::Face::Results
