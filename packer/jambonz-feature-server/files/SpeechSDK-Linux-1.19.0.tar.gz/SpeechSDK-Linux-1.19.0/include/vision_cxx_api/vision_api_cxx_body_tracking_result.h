//
// Copyright (c) Microsoft. All rights reserved.
// See https://aka.ms/azai/vision/license202012 for the full license information.
//

#pragma once

#include <exception>
#include <memory>
#include <string>
#include <vector>

#include <azac_api_cxx_common.h>
#include <azac_api_cxx_details_json.h>
#include <vision_api_cxx_common.h>
#include <vision_api_cxx_frame.h>
#include <vision_api_cxx_details_result_base.h>
#include <vision_api_cxx_body_tracking_result_properties.h>
#include <vision_api_cxx_body_tracking_result_property.h>
#include <vision_api_cxx_body_tracking_result_reason.h>
#include <vision_api_cxx_body_tracking_result_types.h>

namespace Azure {
namespace AI {
namespace Vision {
namespace Body {
namespace Results {

/// <summary>
/// Represents the output an AI inferencing operation (e.g. detection, recognition, prediction, ...).
/// </summary>
class BodyTrackingResult : private Core::Details::ResultBase<BodyTrackingResultReason, BodyTrackingResultProperty, BodyTrackingResultProperties>
{
private:

    using BaseResult = Core::Details::ResultBase<BodyTrackingResultReason, BodyTrackingResultProperty, BodyTrackingResultProperties>;

public:

    /// <summary>
    /// Destructs an instance of the BodyTrackingResult class.
    /// </summary>
    ~BodyTrackingResult() = default;

    /// <summary>
    /// Gets the Media/Frame/FrameSet position that generated this result.  Use the Media Source Reader to retrieve the input.
    /// </summary>
    /// <returns>
    /// The position associated with this result.
    /// </returns>
    uint64_t GetAssociatedMediaPosition() const { return BaseResult::GetAssociatedMediaPosition(); }

    /// <summary>
    /// Gets the FrameSet associated with this result.
    /// </summary>
    /// <returns>
    /// The FrameSet associated with this result.
    /// </returns>
    std::vector<std::shared_ptr<Input::Frames::Frame>> GetAssociatedFrameSet()
    {
        auto reader = BaseResult::GetAssociatedFrameSetReader();
        auto pos = GetAssociatedMediaPosition();

        return reader->ReadFrameSet(pos);
    }

    /// <summary>
    /// Gets the unique id for the Session from which this BodyTrackingResult originated.
    /// </summary>
    /// <returns>
    /// The Session Id string.
    /// </returns>
    std::string GetSessionId() const { return BaseResult::GetSessionId(); }

    /// <summary>
    /// Gets the unique id for the Session from which this BodyTrackingResult originated.
    /// </summary>
    /// <returns>
    /// The Session Id string.
    /// </returns>
    template<class T = std::string>
    AI::Core::Details::enable_if_w_or_string_t<T> GetSessionId() const { return BaseResult::GetSessionId<T>(); }

    /// <summary>
    /// Gets the unique BodyTrackingResult ID for this BodyTrackingResult.
    /// </summary>
    /// <returns>
    /// The unique BodyTrackingResult Id string.
    /// </returns>
    std::string GetResultId() const { return BaseResult::GetResultId(); }

    /// <summary>
    /// Gets the unique BodyTrackingResult ID for this BodyTrackingResult.
    /// </summary>
    /// <returns>
    /// The unique BodyTrackingResult Id string.
    /// </returns>
    template<class T = std::string>
    AI::Core::Details::enable_if_w_or_string_t<T> GetResultId() const { return BaseResult::GetResultId<T>(); }

    /// <summary>
    /// Gets the BodyTrackingResultReason for generation of this result.
    /// </summary>
    BodyTrackingResultReason GetReason() const { return BaseResult::GetReason(BodyTrackingResultReason::NoMatch, BodyTrackingResultReason::Recognized); }

    /// <summary>
    /// Gets the list of Bodies for this result
    /// </summary>
    std::vector<Body> GetBodies() const
    {
        std::vector<Body> bodies;

        auto insightsJson = Properties.Get("insightsJson");

        auto insightsParser = AI::Core::Details::Json::JsonValue::Parse(insightsJson.c_str(), insightsJson.size());
        auto insightJson = insightsParser["insight_list"][0]["insight_json"];

        auto detections = insightJson["detections"];
        for (int i = 0; i < detections.Count(); i++)
        {
            auto detection = detections[i];
            if (detection["type"].AsString() != "person")
            {
                continue;
            }

            Body body {};
            body.Id = std::stoul(detection["metadata"]["trackingId"].AsString());

            auto joints = detection["region"]["jointlist"]["joints"];
            if (joints.Count() != Skeleton::JointCount)
            {
                throw std::runtime_error("BodyTracking result does not have the correct number of joints");
            }

            for (int j = 0; j < Skeleton::JointCount; j++)
            {
                auto joint = joints[j];
                auto& outputJoint = body.Skeleton.Joints[j];
                outputJoint.ConfidenceLevel = static_cast<Results::JointConfidenceLevel>(joint["confidence"].AsInt());

                auto point = joint["point"];
                outputJoint.Position.XYZ.X = point["x"].AsFloat();
                outputJoint.Position.XYZ.Y = point["y"].AsFloat();
                outputJoint.Position.XYZ.Z = point["z"].AsFloat();

                auto orientation = joint["orientation"];
                outputJoint.Orientation.WXYZ.W = orientation["w"].AsFloat();
                outputJoint.Orientation.WXYZ.X = orientation["x"].AsFloat();
                outputJoint.Orientation.WXYZ.Y = orientation["y"].AsFloat();
                outputJoint.Orientation.WXYZ.Z = orientation["z"].AsFloat();
            }

            bodies.push_back(body);
        }

        return bodies;
    }

    /// <summary>
    /// Gets a collection of additional inferencing operation properties.
    /// </summary>
    const BodyTrackingResultProperties& Properties;

protected:

    static std::shared_ptr<BodyTrackingResult> FromHandle(AZAC_HANDLE handle)
    {
        auto ptr = new BodyTrackingResult(handle);
        return std::shared_ptr<BodyTrackingResult>(ptr);
    }

    explicit BodyTrackingResult(AZAC_HANDLE result) :
        ResultBase(result),
        Properties(GetProperties())
    {
    }

    explicit operator AZAC_HANDLE() { return AI::Core::Details::ProtectedAccess<BaseResult>::HandleFromPtr(this); }

private:

    AZAC_DISABLE_DEFAULT_CTORS(BodyTrackingResult);
};

} } } } } // Azure::AI::Vision::Body::Results
