//
// Copyright (c) Microsoft. All rights reserved.
// See https://aka.ms/azai/vision/license202012 for the full license information.
//

#pragma once
#include <azac_api_cxx_details_property_collection.h>
#include <vision_api_cxx_common.h>

namespace Azure {
namespace AI {
namespace Vision {
namespace Service {

enum class VisionServiceOption
{
    Endpoint = 0,
    HttpProxy = 1,
    HttpProxyUserName = 2,
    HttpProxyPassword = 3

    // TODO: TFS#3664448 - Vision: What VisionServiceOption's should we have?
};

} } } } // Azure::AI::Vision::Service

PRIVATE_PROPERTY_COLLECTION_STATICS(Azure::AI::Vision::Service::VisionServiceOption, "service")
