//
// Copyright (c) Microsoft. All rights reserved.
// See https://aka.ms/azai/vision/license202012 for the full license information.
//

#pragma once
#include <vision_api_cxx_common.h>
#include <vision_api_cxx_details_result_event_args_base.h>
#include <vision_api_cxx_body_tracking_result.h>

namespace Azure {
namespace AI {
namespace Vision {
namespace Body {
namespace Events {

/// <summary>
/// Event args for a tracked body.
/// </summary>
class BodyTrackingEventArgs : private Core::Details::ResultEventArgsBase<Results::BodyTrackingResult, int>
{
private:

    using BaseResultEventArgs = Core::Details::ResultEventArgsBase<Results::BodyTrackingResult, int>;

public:

    /// <summary>
    /// Gets the Result of an AI inteferening operation
    /// </summary>
    /// <returns>The BodyTrackingResult wrapped inside a std::shared_ptr</returns>
    std::shared_ptr<Results::BodyTrackingResult> GetResult() const { return BaseResultEventArgs::GetResult(); }

protected:

    static std::shared_ptr<BodyTrackingEventArgs> FromHandle(AZAC_HANDLE handle)
    {
        auto ptr = new BodyTrackingEventArgs(handle);
        return std::shared_ptr<BodyTrackingEventArgs>(ptr);
    }

    explicit BodyTrackingEventArgs(AZAC_HANDLE eventArgs) : ResultEventArgsBase(eventArgs)
    {
    }

private:

    AZAC_DISABLE_DEFAULT_CTORS(BodyTrackingEventArgs);
};

} } } } } // Azure::AI::Vision::Body::Results
