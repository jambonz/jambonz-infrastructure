//
// Copyright (c) Microsoft. All rights reserved.
// See https://aka.ms/azai/vision/license202012 for the full license information.
//

#pragma once

#include <initializer_list>
#include <memory>
#include <utility>
#include <vector>

#include <azac_api_cxx_details_property_collection.h>
#include <vision_api_cxx_common.h>
#include <vision_api_cxx_frame.h>
#include <vision_api_c_frame_writer.h>

namespace Azure {
namespace AI {
namespace Vision {
namespace Input {
namespace Frames {

// TODO: TFS#3664413 - What to do about stream parameter? (feedback from ryan)

/// <summary>
/// Represents the ability to write image frame data, for use as input w/ Vision AI scenario operations.
/// </summary>
class FrameSetWriter
{
public:

    /// <summary>
    /// Destructs an instance of the FrameSetWriter class.
    /// </summary>
    virtual ~FrameSetWriter()
    {
        if (vision_frame_writer_handle_is_valid(m_frameWriter))
        {
            vision_frame_writer_handle_release(m_frameWriter);
            m_frameWriter = AZAC_HANDLE_INVALID;
        }
    };

    void Close()
    {
        AZAC_THROW_ON_FAIL(vision_frame_writer_close(m_frameWriter));
    }

    /// <summary>
    /// Writes a set of Frames of image data to the underlying FrameSetSource.
    /// </summary>
    void WriteFrameSet(std::initializer_list<const std::pair<uint8_t *, size_t>> frames)
    {
        uint32_t i = 0;

        for (auto frame : frames)
        {
            if (frame.first && frame.second)
            {
                uint32_t size = (uint32_t)frame.second; // idiomatic to accept size_t, but C API uses uint32_t
                AZAC_THROW_ON_FAIL(vision_frame_writer_write_with_properties(m_frameWriter, i++, frame.first, size, nullptr));
            }
            else
            {
                AZAC_THROW_ON_FAIL(vision_frame_writer_write_with_properties(m_frameWriter, i++, nullptr, 0, nullptr));
            }
        }
    }

    /// <summary>
    /// Writes a set of Frames of image data to the underlying FrameSetSource.
    /// </summary>
    template<typename T = std::initializer_list<std::shared_ptr<Frame>>, std::enable_if_t<Core::Details::is_container_of<T, std::shared_ptr<Frame>>::value, int> = 0>
    void WriteFrameSet(T&& frames)
    {
        uint32_t i = 0;

        for (auto frame : frames)
        {
            if (frame)
            {
                uint32_t size = (uint32_t)frame->DataSizeInBytes; // idiomatic to accept size_t, but C API uses uint32_t
                AZAC_THROW_ON_FAIL(vision_frame_writer_write_with_properties(m_frameWriter, i++, frame->Data, size, AI::Core::Details::ProtectedAccess<Frame>::HandleFromPtr(frame.get())));
            }
            else
            {
                AZAC_THROW_ON_FAIL(vision_frame_writer_write_with_properties(m_frameWriter, i++, nullptr, 0, nullptr));
            }
        }
    }

protected:

    static std::shared_ptr<FrameSetWriter> FromHandle(AZAC_HANDLE handle)
    {
        auto ptr = new FrameSetWriter(handle);
        return std::shared_ptr<FrameSetWriter>(ptr);
    }

    explicit FrameSetWriter(AZAC_HANDLE frameWriter) :
        m_frameWriter(frameWriter)
    {
    }

    explicit operator AZAC_HANDLE() { return m_frameWriter; }

private:

    AZAC_DISABLE_DEFAULT_CTORS(FrameSetWriter);

    AZAC_HANDLE m_frameWriter;
};

}
}
}
}
} // Azure::AI::Vision::Input::Frames
