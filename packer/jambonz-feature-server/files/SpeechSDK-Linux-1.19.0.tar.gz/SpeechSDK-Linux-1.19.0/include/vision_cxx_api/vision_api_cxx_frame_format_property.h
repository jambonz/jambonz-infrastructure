//
// Copyright (c) Microsoft. All rights reserved.
// See https://aka.ms/azai/vision/license202012 for the full license information.
//

#pragma once
#include <azac_api_cxx_details_property_collection.h>
#include <vision_api_cxx_common.h>

namespace Azure {
namespace AI {
namespace Vision {
namespace Input {
namespace Frames {

enum class FrameFormatProperty
{
    TODO = -1

    // TODO: TFS#3664169 - What FrameFormatProperty's do we want?
};

} } } } } // Azure::AI::Vision::Input::Frames

PRIVATE_PROPERTY_COLLECTION_STATICS(Azure::AI::Vision::Input::Frames::FrameFormatProperty, "frame.format")
