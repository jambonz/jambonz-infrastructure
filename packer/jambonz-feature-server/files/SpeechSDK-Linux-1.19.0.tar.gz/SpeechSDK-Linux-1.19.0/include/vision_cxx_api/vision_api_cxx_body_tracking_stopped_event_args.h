//
// Copyright (c) Microsoft. All rights reserved.
// See https://aka.ms/azai/vision/license202012 for the full license information.
//

#pragma once
#include <vision_api_cxx_common.h>
#include <vision_api_cxx_details_session_stopped_event_args_base.h>
#include <vision_api_cxx_body_tracking_stopped_reason.h>

namespace Azure {
namespace AI {
namespace Vision {
namespace Body {
namespace Events {

/// <summary>
/// Represents inference processing stopping.
/// </summary>
class BodyTrackingStoppedEventArgs : private Core::Details::SessionStoppedEventArgsBase<Results::BodyTrackingStoppedReason, int>
{
private:

    template<typename Target>
    using ProtectedAccess = AI::Core::Details::ProtectedAccess<Target>;
    using BaseEventArgs = Core::Details::SessionStoppedEventArgsBase<Results::BodyTrackingStoppedReason, int>;

public:

    /// <summary>
    /// Gets the unique Session ID from which this Event originated.
    /// </summary>
    /// <returns>
    /// The Session ID string.
    /// </returns>
    std::string GetSessionId() const { return BaseEventArgs::GetSessionId(); }

    /// <summary>
    /// Gets the unique Session ID from which this Event originated.
    /// </summary>
    /// <returns>
    /// The Session ID string.
    /// </returns>
    template<class T = std::string>
    AI::Core::Details::enable_if_w_or_string_t<T> GetSessionId() const { return BaseEventArgs::GetSessionId<T>(); }

    /// <summary>
    /// Gets the SessionStoppedReason for generation of this result.
    /// </summary>
    Results::BodyTrackingStoppedReason GetReason() const { return BaseEventArgs::GetReason(Results::BodyTrackingStoppedReason::Error, Results::BodyTrackingStoppedReason::StopRequested); }

protected:

    static std::shared_ptr<BodyTrackingStoppedEventArgs> FromHandle(AZAC_HANDLE handle)
    {
        auto ptr = new BodyTrackingStoppedEventArgs(handle);
        return std::shared_ptr<BodyTrackingStoppedEventArgs>(ptr);
    }

    explicit BodyTrackingStoppedEventArgs(AZAC_HANDLE eventArgs) : SessionStoppedEventArgsBase(eventArgs)
    {
    }

    explicit operator AZAC_HANDLE() const { return ProtectedAccess<EventArgsBase>::HandleFromConstPtr(this); }

private:

    AZAC_DISABLE_DEFAULT_CTORS(BodyTrackingStoppedEventArgs);
};

} } } } } // Azure::AI::Vision::Body::Events
