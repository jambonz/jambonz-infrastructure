//
// Copyright (c) Microsoft. All rights reserved.
// See https://aka.ms/azai/vision/license202012 for the full license information.
//

#pragma once
#include <vision_api_cxx_common.h>

namespace Azure {
namespace AI {
namespace Vision {
namespace Body {
namespace Results {

enum class BodyTrackingResultProperty
{
    Json = 0

    // TODO: TFS#3426383 - Vision BT: Body Tracker family specific options and properties (C++)
};

} } } } } // Azure::AI::Vision::Body::Results

PRIVATE_PROPERTY_COLLECTION_STATICS(Azure::AI::Vision::Body::Results::BodyTrackingResultProperty, "body.result")
